package com.example.visualizevocabulary.Model;

public class leaderboardModel {
    String name;

    public leaderboardModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
