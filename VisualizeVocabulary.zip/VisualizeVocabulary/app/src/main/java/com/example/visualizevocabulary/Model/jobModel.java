package com.example.visualizevocabulary.Model;

public class jobModel {
    String jobImage;

    public jobModel(String jobImage) {
        this.jobImage = jobImage;
    }

    public String getJobImage() {
        return jobImage;
    }

    public void setJobImage(String jobImage) {
        this.jobImage = jobImage;
    }
}
